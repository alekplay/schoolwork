#include "cachelab.h"
#include <unistd.h>
#include <stdlib.h>
#include <getopt.h>
#include <stdio.h>

#define BUF_LENGTH 50

typedef struct strLine {
    int iValid;
    long lTag;
} sLine;

typedef struct strSet {
    sLine *pLine;
} sSet;

int main(int argc, char *argv[])
{
    printf("yolo");

    FILE *pFile;
    int i, j;
    int is, iS, iE, ib;
    int iV = 0;
    sSet *pCache;
    char achTrace[BUF_LENGTH];
    int iOpt;
    long lMaskS, lMaskT;
    int iSet;
    long lTag;
    int iMissFlag;
    int iHit = 0, iMiss = 0, iEvict = 0;
    char chOpt;
    long lAddr;
    int iSize;

    printf("heyaa");

    while((iOpt = getopt(argc, argv, "s:E:b:t")) != -1) {
        switch(iOpt) {
	    case 's':
		is = atoi(optarg);
		iS = 1 << is;
		lMaskS = iS - 1;
  		break;
	    case 'E':
		iE = atoi(optarg);
		break;
	    case 'b':
		ib = atoi(optarg);
		break;
	    case 't':
		pFile = fopen(optarg, "r");
		break;
	    default:
		return 1;
	}
    }
    lMaskT = -1 << (ib + is);

    printf("Got here");

    pCache = (sSet * )malloc(iS * sizeof(sSet));
    for (i = 0; i != iS; ++i) {
	pCache[i].pLine = (sLine *)malloc(iE * sizeof(sLine));
  	for(j = 0; j != iE; ++j) {
	    pCache[i].pLine[j].iValid = 0;
	}
    }

    while (fgets(achTrace, BUF_LENGTH, pFile)) {
	sscanf(achTrace, " %c %lx,%d", &chOpt, &lAddr, &iSize);
  	lTag = lAddr & lMaskT;
	iSet = (lAddr >> ib) & lMaskS;
	switch(chOpt) {
	    case 'M':
		if(iV) {
		    printf("%c %lx,%d", chOpt, lAddr, iSize);
		}
		iMissFlag = 1;
 		for (i = 0; i!= iE && iMissFlag; ++i) {
		    if (pCache[iSet].pLine[i].iValid && pCache[iSet].pLine[i].lTag == lTag) {
			iMissFlag = 0;
			iHit += 2;
			for (j = 1; j!= i+1; ++j) {
			    pCache[iSet].pLine[i + 1 - j].iValid = pCache[iSet].pLine[i - j].iValid;
 			    pCache[iSet].pLine[i + 1 - j].lTag = pCache[iSet].pLine[i - j].lTag;
			}
			pCache[iSet].pLine[0].iValid = 1;
			pCache[iSet].pLine[0].lTag = lTag;
			if (iV) {
			    printf(" hit hit \n");
			}
		    }
		}

		if (iMissFlag) {
		    ++iHit;
		    ++iMiss;
		    if(iV) {
			printf(" miss");
		    }
		    if(pCache[iSet].pLine[iE - 1].iValid) {
			++iEvict;
			if(iV) {
			    printf(" eviction");
			}
		    }
		    for (i = 1; i!= iE; ++i) {
			pCache[iSet].pLine[iE - i].iValid = pCache[iSet].pLine[iE - 1 - i].iValid;
  			pCache[iSet].pLine[iE - i].lTag = pCache[iSet].pLine[iE - 1 - i].lTag;
		    }
		    pCache[iSet].pLine[0].iValid = 1;
		    pCache[iSet].pLine[0].lTag = lTag;
		    if (iV) {
			printf(" hit\n");
		    }
		}
		break;
	    case 'L':
	    case 'S':
		if(iV) {
		    printf("%c %lx,%d", chOpt, lAddr, iSize);
		}
		iMissFlag = 1;
		for (i = 0; i!= iE && iMissFlag; ++i) {
		    if(pCache[iSet].pLine[i].iValid && pCache[iSet].pLine[i].lTag == lTag) {
			iMissFlag = 0;
			++iHit;
			for (j = 1; j != i; ++j) {
			    pCache[iSet].pLine[i + 1 - j].iValid = pCache[iSet].pLine[i - j].iValid;
			    pCache[iSet].pLine[i + 1 - j].lTag = pCache[iSet].pLine[i - j].lTag;
			}
			pCache[iSet].pLine[0].iValid = 1;
			pCache[iSet].pLine[0].lTag = lTag;
			if (iV) {
			    printf(" hit \n");
			}
		    }
		}
		if (iMissFlag) {
		    ++iMiss;
		    if(iV) {
			printf(" miss");
		    }
		    if (pCache[iSet].pLine[iE - 1].iValid) {
			if (iV) {
			    printf(" eviction");
			}
			++iEvict;
		    }
		    for (i = 1; i != iE; ++i) {
			pCache[iSet].pLine[iE - i].iValid = pCache[iSet].pLine[iE - 1 - i].iValid;
			pCache[iSet].pLine[iE - i].lTag = pCache[iSet].pLine[iE - 1 - i].lTag;
		    }
		    pCache[iSet].pLine[0].iValid = 1;
		    pCache[iSet].pLine[0].lTag = lTag;
		    printf("\n");
		}
		break;
	    default:
		;
	}
    }
    printSummary(iHit, iMiss, iEvict);

    for (i = 0; i != iS; ++i) {
	free(pCache[i].pLine);
    }
    free(pCache);
    fclose(pFile);

    return 0;
}
